# ClickHouse & Flat File Data Ingestion Tool

This project is a simplified data ingestion tool developed as part of the **Zeotap Software Engineer Intern assignment**. It enables bidirectional data transfer between **ClickHouse databases** and **flat files (CSV/TSV)** using a basic Java backend and HTML frontend.

... (content truncated here to save space; full version will be in the file)
